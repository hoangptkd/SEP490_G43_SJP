---
name: Nexus Recruit
colors:
  surface: '#f7f9ff'
  surface-dim: '#d3dbe5'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef4ff'
  surface-container: '#e5efff'
  surface-container-high: '#dbe9ff'
  surface-container-highest: '#d4e4fa'
  on-surface: '#151c24'
  on-surface-variant: '#40474f'
  inverse-surface: '#293139'
  inverse-on-surface: '#eaf1fc'
  outline: '#707881'
  outline-variant: '#c0c7d1'
  surface-tint: '#236391'
  primary: '#00507d'
  on-primary: '#ffffff'
  primary-container: '#2b6897'
  on-primary-container: '#cbe4ff'
  inverse-primary: '#95ccff'
  secondary: '#565e74'
  on-secondary: '#ffffff'
  secondary-container: '#d7dff9'
  on-secondary-container: '#5a6278'
  tertiary: '#3d4d62'
  on-tertiary: '#ffffff'
  tertiary-container: '#55657b'
  on-tertiary-container: '#d2e2fc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#cde5ff'
  primary-fixed-dim: '#95ccff'
  on-primary-fixed: '#001d32'
  on-primary-fixed-variant: '#004a75'
  secondary-fixed: '#dae2fc'
  secondary-fixed-dim: '#bec6e0'
  on-secondary-fixed: '#131b2e'
  on-secondary-fixed-variant: '#3e465b'
  tertiary-fixed: '#d3e4fe'
  tertiary-fixed-dim: '#b7c8e1'
  on-tertiary-fixed: '#0b1c2f'
  on-tertiary-fixed-variant: '#38485d'
  background: '#f7f9ff'
  on-background: '#151c24'
  surface-variant: '#dbe3ed'
  match-indicator: '#0369a1'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  2xl: 48px
  3xl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style
Nexus Recruit embodies a **Corporate Modern** aesthetic that prioritizes utility, clarity, and trust. The brand personality is professional and systematic, designed to feel like a high-performance tool rather than a social platform. 

The visual language uses a disciplined palette of deep blues and cool grays to evoke stability. High-density information is managed through a clear hierarchy of surface tiers and subtle borders. The emotional response is one of reliability and efficiency, catering to professional job seekers and recruiters who value speed and accuracy over decorative flourishes.

## Colors
The color system is built on a **Fidelity** variant of deep oceanic blues. The primary color (#00507d) is reserved for brand identification, primary actions, and active states to maintain high task focus. 

We utilize a sophisticated "Surface Container" logic for depth:
- **Lowest (#ffffff):** Used for cards and primary content areas to maximize legibility.
- **Low (#eef4ff):** Used for large background sections or "Hero" containers to provide soft differentiation from the main background.
- **Highest (#d4e4fa):** Reserved for hover states and subtle UI dividers.

Neutral tones are strictly cool-gray to prevent the interface from feeling "muddy," ensuring that the blue primary accents remain crisp and authoritative.

## Typography
The system uses **Inter** exclusively to leverage its exceptional legibility in data-heavy environments. 

- **Display & Headlines:** Use tight line-heights and slight negative letter-spacing to create a "locked-in" professional look. 
- **Body Text:** Standard body copy is `body-md` (16px), while supplemental information (metadata, timestamps) utilizes `body-sm`.
- **Labels:** Used for buttons and chips. They feature a semi-bold or medium weight to distinguish them from flow text.

## Layout & Spacing
Nexus Recruit follows a **Fixed Grid** philosophy for desktop, centering content within a 1280px max-width container to prevent line-lengths from becoming uncomfortable.

- **Grid:** A 12-column structure is used for the main feed, with a 3-column (approx 250px) sidebar for filters.
- **Rhythm:** We use a base-4 vertical rhythm. Standard padding for cards and sections is `md` (16px) or `lg` (24px) depending on importance.
- **Breakpoints:** On mobile, the sidebar collapses into a hidden drawer or moves below the search hero, and horizontal padding reduces to `md`.

## Elevation & Depth
Depth is conveyed through a combination of **Tonal Layers** and **Ambient Shadows**.

- **Surface Tiers:** Backgrounds use `surface` (#f8f9ff), while interactive cards use `surface-container-lowest` (#ffffff).
- **Shadows:** We use a single, extremely soft shadow (`shadow-sm`) for interactive elements like cards and navigation bars: `0 1px 3px rgba(15, 23, 42, 0.08)`.
- **Interactions:** On hover, cards transition to a slightly deeper shadow to simulate physical lift, providing clear affordance.
- **Dividers:** Use `outline-variant` (#c0c7d1) for structural separation where tonal changes are too subtle.

## Shapes
The shape language is **Soft (Level 1)**, balancing corporate rigor with modern approachability.

- **Standard Buttons & Inputs:** 4px (`rounded`) radius.
- **Cards & Hero Sections:** 8px (`rounded-lg`) or 12px (`rounded-xl`) radius to soften the layout's large containers.
- **Profile Images & Tags:** Full (`rounded-full`) for avatars and status indicators (like the "Match %" badge) to differentiate them from functional UI blocks.

## Components

### Buttons
- **Primary:** Solid `#00507d` background with white text. 4px roundedness.
- **Secondary/Outline:** 1px border using `outline-variant`, primary colored text.
- **Hover States:** Primary buttons reduce opacity slightly (90%); secondary buttons use a light tint (`surface-container-highest`) as a background fill.

### Input Fields
- Inputs use `surface-container-lowest` background with a 1px `outline-variant` border.
- Icons (Material Symbols) are placed at the start with `on-surface-variant` coloring.
- Focus state: 2px ring of `primary` at 20% opacity.

### Job Cards
- White background, 1px `outline-variant` border, and `shadow-sm`.
- Inner layout uses a flexible flexbox grid: Logo (48px fixed) | Content | Actions.
- Metadata (salary, location) uses `body-sm` with leading icons.

### Chips/Tags
- Small, 12px text, 4px padding.
- Use a subtle `surface-container-low` background to separate them from the card surface without drawing excessive attention.

### Filters
- Vertical stacks of checkboxes with `sm` (8px) gap.
- Checkboxes use `primary` color for the checked state.